package com.codingbox.jpaitem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaitemApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaitemApplication.class, args);
	}

}
